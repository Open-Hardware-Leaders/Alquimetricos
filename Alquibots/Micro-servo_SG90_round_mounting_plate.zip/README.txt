                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2049935
Micro-servo (SG90) round mounting plate by mavu is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I made this mounting plate for a micro servo because my 9G servos didn't have the disc mount which was used in this robot arm model (http://www.thingiverse.com/thing:1684471)

It fits my "Tower Pro" SG90 micro servos, which have 20 tiny teeth on the shaft.

the base of the plate is a bit over 20mm diameter.

You need to scale it to fit your printer and currently used filament.

Printed on my MK2, they fit with
95% (tight)
96% (still tight, but less hard to press on)
97% just gripping.

You can barely see the teeth on the printed part, but they are there, and with the correct scaling work just fine. 

I only tried PLA.

# Print Settings

Printer: Original Prusa I3 MK2
Rafts: No
Supports: No
Resolution: 0.2
Infill: -

Notes: 
Remember to scale for your printer and filament, start with 96%

# How I Designed This

Made with FreeCAD, and abusing the "involute gear helper".
Basically made by the equivalent of bashing something with a hammer until it fits. 
Its not pretty, but I'm uploading the freecad file anyway :)